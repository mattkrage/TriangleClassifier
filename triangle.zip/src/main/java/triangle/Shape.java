package triangle;

public interface Shape {
}
