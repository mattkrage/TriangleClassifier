package triangle;

public class InvalidInputException extends Exception {
    InvalidInputException(String message) {
        super(message);
    }
}