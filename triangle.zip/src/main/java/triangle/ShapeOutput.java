package triangle;

public interface ShapeOutput {

    void printType(String bundleKey);

    void printError(String message);

}
